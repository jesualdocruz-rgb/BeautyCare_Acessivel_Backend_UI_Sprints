import React, { useCallback, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, CalendarDays, UserRound, Accessibility, Star, MapPin, RefreshCw, Scissors, HeartHandshake } from 'lucide-react';
import './style.css';

// Local development: http://127.0.0.1:8000
// Production: configure VITE_API_URL with the public Render API URL.
const API = (import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');

async function apiGet(path) {
  const response = await fetch(`${API}${path}`);
  if (!response.ok) throw new Error(`A API respondeu com erro (${response.status}).`);
  return response.json();
}

function App() {
  const [professionals, setProfessionals] = useState([]);
  const [query, setQuery] = useState('');
  const [accessibleOnly, setAccessibleOnly] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [loading, setLoading] = useState(true);
  const [apiStatus, setApiStatus] = useState('checking');
  const [error, setError] = useState('');
  const [servicesByProfessional, setServicesByProfessional] = useState({});
  const [serviceLoading, setServiceLoading] = useState(null);

  useEffect(() => {
    let active = true;
    apiGet('/health')
      .then(() => { if (active) setApiStatus('online'); })
      .catch(() => { if (active) setApiStatus('offline'); });
    return () => { active = false; };
  }, []);

  const loadProfessionals = useCallback(async () => {
    setLoading(true);
    setError('');
    const params = new URLSearchParams();
    if (query.trim()) params.set('q', query.trim());
    if (accessibleOnly) params.set('accessible', 'true');
    try {
      const data = await apiGet(`/api/professionals${params.size ? `?${params}` : ''}`);
      setProfessionals(data);
      setApiStatus('online');
    } catch (err) {
      setError('Não foi possível carregar os profissionais. Confira se a API está ativa e se VITE_API_URL está configurada corretamente.');
      setApiStatus('offline');
      setProfessionals([]);
    } finally {
      setLoading(false);
    }
  }, [query, accessibleOnly]);

  useEffect(() => {
    const timer = setTimeout(loadProfessionals, 250);
    return () => clearTimeout(timer);
  }, [loadProfessionals]);

  async function toggleServices(professionalId) {
    if (servicesByProfessional[professionalId]) {
      setServicesByProfessional(prev => ({ ...prev, [professionalId]: null }));
      return;
    }
    setServiceLoading(professionalId);
    try {
      const services = await apiGet(`/api/services?professional_id=${professionalId}`);
      setServicesByProfessional(prev => ({ ...prev, [professionalId]: services }));
    } catch {
      setServicesByProfessional(prev => ({ ...prev, [professionalId]: [] }));
    } finally {
      setServiceLoading(null);
    }
  }

  return <div className={largeText ? 'app large' : 'app'}>
    <header>
      <a className="brand" href="#inicio" aria-label="BeautyCare Acessível, início">BeautyCare <span>Acessível</span></a>
      <button className="access-button" onClick={() => setLargeText(v => !v)} aria-pressed={largeText}>
        <Accessibility size={18} /> {largeText ? 'Texto normal' : 'Acessibilidade'}
      </button>
    </header>

    <main id="inicio">
      <section className="hero">
        <small>BELEZA PARA TODOS</small>
        <h1>Encontre um profissional perto de você.</h1>
        <p>Uma experiência de busca simples, confortável e acessível.</p>
        <div className={`api-status ${apiStatus}`} role="status">
          <span className="status-dot" />
          {apiStatus === 'online' ? 'Conectado à API' : apiStatus === 'offline' ? 'API indisponível' : 'Verificando conexão…'}
        </div>
      </section>

      <div className="search" role="search">
        <Search aria-hidden="true" />
        <input value={query} onChange={e => setQuery(e.target.value)} aria-label="Buscar profissionais" placeholder="Buscar nome, serviço ou localização…" />
        {query && <button className="clear-button" onClick={() => setQuery('')} aria-label="Limpar busca">×</button>}
      </div>

      <label className="filter">
        <input type="checkbox" checked={accessibleOnly} onChange={e => setAccessibleOnly(e.target.checked)} />
        <Accessibility size={18} /> Mostrar somente profissionais com atendimento acessível
      </label>

      <div className="section-heading">
        <div><h2>Profissionais</h2><p>Informações carregadas do back-end</p></div>
        <button className="refresh-button" onClick={loadProfessionals} aria-label="Atualizar profissionais"><RefreshCw size={17} /></button>
      </div>

      {loading && <p className="message" role="status">Carregando profissionais…</p>}
      {!loading && error && <div className="error" role="alert"><b>Não foi possível conectar.</b><p>{error}</p><button onClick={loadProfessionals}>Tentar novamente</button><p className="small-note">API configurada: <code>{API}</code></p></div>}
      {!loading && !error && professionals.length === 0 && <div className="empty"><HeartHandshake size={28}/><b>Nenhum profissional encontrado</b><p>Tente outro termo ou desative o filtro de acessibilidade.</p></div>}

      {!loading && !error && professionals.map(pro => <article className="professional" key={pro.id}>
        <div className="avatar" aria-hidden="true">{(pro.name || 'BC').slice(0, 2).toUpperCase()}</div>
        <div className="professional-info">
          <h3>{pro.name}</h3>
          <p>{pro.specialty}</p>
          <div className="meta"><span><Star size={14} fill="currentColor" /> {Number(pro.rating || 0).toFixed(1)}</span><span><MapPin size={14} /> {pro.location}</span></div>
          <span className={pro.accessible ? 'access-tag' : 'standard-tag'}>{pro.accessible ? 'Atendimento acessível' : 'Acessibilidade não informada'}</span>
          <button className="services-button" onClick={() => toggleServices(pro.id)} disabled={serviceLoading === pro.id}>
            <Scissors size={16} /> {serviceLoading === pro.id ? 'Carregando serviços…' : servicesByProfessional[pro.id] ? 'Ocultar serviços' : 'Ver serviços e preços'}
          </button>
          {Array.isArray(servicesByProfessional[pro.id]) && <div className="services-list">
            {servicesByProfessional[pro.id].length ? servicesByProfessional[pro.id].map(service => <div className="service-row" key={service.id}><span>{service.name}</span><b>{Number(service.price).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</b></div>) : <p>Nenhum serviço cadastrado para este profissional.</p>}
          </div>}
        </div>
      </article>)}
    </main>

    <nav aria-label="Navegação principal">
      <a href="#inicio"><Search size={20} /><span>Buscar</span></a>
      <a href="#agenda" onClick={e => { e.preventDefault(); alert('A agenda será conectada na próxima etapa da integração.'); }}><CalendarDays size={20} /><span>Agenda</span></a>
      <a href="#perfil" onClick={e => { e.preventDefault(); alert('O perfil e a autenticação serão implementados na próxima etapa.'); }}><UserRound size={20} /><span>Perfil</span></a>
    </nav>
    <footer>BeautyCare Acessível · Projeto acadêmico GRUPO 02 UAPI</footer>
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
