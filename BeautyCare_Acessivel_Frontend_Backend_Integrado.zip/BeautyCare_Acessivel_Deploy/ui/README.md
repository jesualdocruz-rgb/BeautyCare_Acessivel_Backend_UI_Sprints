# Front-end — BeautyCare Acessível

## Integração com a API
A interface React/Vite consulta a API FastAPI por meio de `VITE_API_URL`.

- `GET /health`: verifica se o back-end está respondendo.
- `GET /api/professionals?q=...&accessible=true`: pesquisa e filtra profissionais.
- `GET /api/services?professional_id=...`: carrega serviços e preços de um profissional.

### Desenvolvimento local
1. Inicie a API na porta 8000 conforme `../api/README.md`.
2. Crie `ui/.env` com `VITE_API_URL=http://127.0.0.1:8000`.
3. Execute `npm install` e `npm run dev`.

### Publicação
Na Vercel, configure a variável de ambiente `VITE_API_URL` com a URL pública real da API publicada no Render. Não inclua `/docs` nem barra final. Após alterar a variável, faça novo deploy.

> O fluxo de agenda, perfil/autenticação e criação de agendamentos ainda não está conectado na interface.
