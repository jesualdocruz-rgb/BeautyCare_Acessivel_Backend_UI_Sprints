# BeautyCare Acessível — Plano de Execução

## Artefato 1 — Tecnologias Back-End
Python, FastAPI, Uvicorn, SQLAlchemy, SQLite, Pydantic, Swagger/OpenAPI e Git/GitHub/GitLab.

## Artefato 2 — Repositório remoto
Nome sugerido: `beautycare-acessivel-api`.

```bash
git init
git branch -M main
git add .
git commit -m "feat: estrutura inicial da API"
git remote add origin URL_DO_REPOSITORIO
git push -u origin main
```

## Artefato 3 — Projeto API e versionamento
A API implementa usuários, profissionais, serviços e agendamentos, com persistência SQLite, validação Pydantic e documentação Swagger.

## Artefato 4 — Projeto API: mínimo 8 tarefas
1. API-01 Definir tecnologias back-end — Concluída
2. API-02 Criar projeto FastAPI — Concluída
3. API-03 Configurar ambiente e dependências — Concluída
4. API-04 Configurar SQLite + SQLAlchemy — Concluída
5. API-05 Criar modelos de domínio — Concluída
6. API-06 Criar schemas/DTOs — Concluída
7. API-07 Implementar endpoints de usuários/profissionais — Concluída
8. API-08 Implementar serviços/agendamentos — Concluída
9. API-09 Implementar busca e filtro de acessibilidade — Concluída
10. API-10 Documentar/testar Swagger — Concluída

## Artefato 5 — Projeto UI: mínimo 8 tarefas
1. UI-01 Definir tecnologias Front-End — Concluída
2. UI-02 Criar React/Vite — Concluída
3. UI-03 Configurar Git/repositório — Preparada
4. UI-04 Criar identidade visual acessível — Concluída
5. UI-05 Implementar Login/Cadastro — Estruturada para próxima iteração
6. UI-06 Implementar Home — Concluída
7. UI-07 Implementar busca de profissionais — Concluída
8. UI-08 Implementar perfil profissional — Base preparada
9. UI-09 Implementar fluxo de agendamento — Preparada para integração
10. UI-10 Implementar Agenda — Estruturada
11. UI-11 Acessibilidade/responsividade — Concluída
12. UI-12 Integração com API — Concluída para listagem de profissionais

## Trello
PRODUCT BACKLOG -> SPRINT 1 – A FAZER -> EM DESENVOLVIMENTO -> EM TESTE -> CONCLUÍDO.


## Artefato adicional — Publicação
- UI: preparada para Vercel com `vercel.json` e variável `VITE_API_URL`.
- API: preparada para Render com `render.yaml`, rota `/health` e configuração CORS.
- **Status real:** configuração de publicação preparada; deploy público depende de importar o repositório e executar o deploy nas contas do grupo. Registrar as URLs somente após o provedor confirmar a publicação.
