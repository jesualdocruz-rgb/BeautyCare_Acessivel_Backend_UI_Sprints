from sqlalchemy import String,Integer,Float,Boolean,ForeignKey
from sqlalchemy.orm import Mapped,mapped_column,relationship
from .database import Base
class User(Base):
 __tablename__='users'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); email:Mapped[str]=mapped_column(String(160),unique=True); password:Mapped[str]=mapped_column(String(120)); role:Mapped[str]=mapped_column(String(30),default='cliente')
class Professional(Base):
 __tablename__='professionals'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); specialty:Mapped[str]=mapped_column(String(120)); location:Mapped[str]=mapped_column(String(160)); rating:Mapped[float]=mapped_column(Float,default=5); accessible:Mapped[bool]=mapped_column(Boolean,default=True)
class Service(Base):
 __tablename__='services'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); price:Mapped[float]=mapped_column(Float); professional_id:Mapped[int]=mapped_column(ForeignKey('professionals.id'))
class Appointment(Base):
 __tablename__='appointments'; id:Mapped[int]=mapped_column(primary_key=True); date:Mapped[str]=mapped_column(String(20)); time:Mapped[str]=mapped_column(String(10)); status:Mapped[str]=mapped_column(String(30),default='confirmado'); client_id:Mapped[int]=mapped_column(ForeignKey('users.id')); professional_id:Mapped[int]=mapped_column(ForeignKey('professionals.id')); service_id:Mapped[int]=mapped_column(ForeignKey('services.id'))
