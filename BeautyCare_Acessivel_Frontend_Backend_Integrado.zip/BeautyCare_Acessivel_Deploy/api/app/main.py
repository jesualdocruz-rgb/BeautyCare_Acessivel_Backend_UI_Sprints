from fastapi import FastAPI,Depends,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,EmailStr
from sqlalchemy.orm import Session
from sqlalchemy import or_
from .database import Base,engine,get_db
from .models import User,Professional,Service,Appointment
Base.metadata.create_all(engine)
app=FastAPI(title='BeautyCare Acessível API',version='1.0.0',description='API REST do projeto BeautyCare Acessível')

# CORS habilitado para permitir que a UI hospedada na Vercel consuma a API no Render.
# Em produção real, restrinja allow_origins ao domínio específico da Vercel.
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)
class UserIn(BaseModel): name:str; email:EmailStr; password:str; role:str='cliente'
class ProIn(BaseModel): name:str; specialty:str; location:str; rating:float=5; accessible:bool=True
class ServiceIn(BaseModel): name:str; price:float; professional_id:int
class AppointmentIn(BaseModel): date:str; time:str; client_id:int; professional_id:int; service_id:int
@app.get('/')
def root(): return {'message':'BeautyCare Acessível API','docs':'/docs'}
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/api/users',status_code=201)
def create_user(x:UserIn,db:Session=Depends(get_db)):
 if db.query(User).filter_by(email=x.email).first(): raise HTTPException(409,'E-mail já cadastrado')
 o=User(**x.model_dump()); db.add(o); db.commit(); db.refresh(o); return o
@app.get('/api/users')
def users(db:Session=Depends(get_db)): return db.query(User).all()
@app.post('/api/professionals',status_code=201)
def create_pro(x:ProIn,db:Session=Depends(get_db)):
 o=Professional(**x.model_dump()); db.add(o); db.commit(); db.refresh(o); return o
@app.get('/api/professionals')
def professionals(q:str|None=None,accessible:bool|None=None,db:Session=Depends(get_db)):
 r=db.query(Professional)
 if q: r=r.filter(or_(Professional.name.ilike(f'%{q}%'),Professional.specialty.ilike(f'%{q}%'),Professional.location.ilike(f'%{q}%')))
 if accessible is not None: r=r.filter(Professional.accessible==accessible)
 return r.all()
@app.get('/api/professionals/{id}')
def professional(id:int,db:Session=Depends(get_db)):
 o=db.get(Professional,id)
 if not o: raise HTTPException(404,'Profissional não encontrado')
 return o
@app.post('/api/services',status_code=201)
def create_service(x:ServiceIn,db:Session=Depends(get_db)):
 if not db.get(Professional,x.professional_id): raise HTTPException(404,'Profissional não encontrado')
 o=Service(**x.model_dump()); db.add(o); db.commit(); db.refresh(o); return o
@app.get('/api/services')
def services(professional_id:int|None=None,db:Session=Depends(get_db)):
 q=db.query(Service)
 return q.filter_by(professional_id=professional_id).all() if professional_id else q.all()
@app.post('/api/appointments',status_code=201)
def create_appointment(x:AppointmentIn,db:Session=Depends(get_db)):
 for cls,i,msg in [(User,x.client_id,'Cliente não encontrado'),(Professional,x.professional_id,'Profissional não encontrado'),(Service,x.service_id,'Serviço não encontrado')]:
  if not db.get(cls,i): raise HTTPException(404,msg)
 conflict=db.query(Appointment).filter_by(professional_id=x.professional_id,date=x.date,time=x.time,status='confirmado').first()
 if conflict: raise HTTPException(409,'Horário já reservado')
 o=Appointment(**x.model_dump()); db.add(o); db.commit(); db.refresh(o); return o
@app.get('/api/appointments')
def appointments(client_id:int|None=None,db:Session=Depends(get_db)):
 q=db.query(Appointment); return q.filter_by(client_id=client_id).all() if client_id else q.all()
