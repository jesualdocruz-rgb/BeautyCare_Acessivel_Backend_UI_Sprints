# BeautyCare Acessível API
FastAPI + SQLAlchemy + SQLite.

## Executar
python -m venv .venv
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload

Swagger: http://127.0.0.1:8000/docs
