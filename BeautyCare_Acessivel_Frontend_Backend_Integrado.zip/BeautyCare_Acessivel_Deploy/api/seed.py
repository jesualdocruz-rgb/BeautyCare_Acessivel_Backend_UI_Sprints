from app.database import Base,engine,SessionLocal
from app.models import Professional,Service
Base.metadata.create_all(engine); db=SessionLocal()
if not db.query(Professional).count():
 p=Professional(name='Ana Beleza',specialty='Cabeleireira',location='Centro',rating=4.9,accessible=True); db.add(p); db.commit(); db.refresh(p); db.add_all([Service(name='Corte',price=45,professional_id=p.id),Service(name='Hidratação',price=55,professional_id=p.id)]); db.commit()
db.close(); print('Seed concluído')
